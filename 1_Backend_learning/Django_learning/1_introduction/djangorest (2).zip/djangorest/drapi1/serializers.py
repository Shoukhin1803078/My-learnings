from rest_framework import serializers
from .models import A

class ASerializer(serializers.ModelSerializer):
    class Meta:
        model=A
        fields=['id','name','age','email','phone','address','created_at','updated_at']
        # fields='__all__'