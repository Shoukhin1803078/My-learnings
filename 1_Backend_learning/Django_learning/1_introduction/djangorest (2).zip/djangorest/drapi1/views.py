from django.shortcuts import render

# Create your views here.
from .models import A
from .serializers import ASerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET','POST','DELETE','PUT'])
def a_all(request,pk=None):
    if request.method == 'GET':
        if pk is not None:
            a=A.objects.get(pk=pk)
            s=ASerializer(a)
            return Response(s.data)
        else:
            a=A.objects.all()
            s=ASerializer(a,many=True)
            return Response(s.data)
    elif request.method == 'POST':
        s=ASerializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response({
                "message":"Successfully saved"
            })
        return Response(s.errors)
    elif request.method == 'DELETE':
        id=pk
        a=A.objects.get(pk=pk)
        a.delete()
        return Response({
            "message":"{pk} id is deleted"
        })
    elif request.method == 'PUT':
        a=A.objects.get(pk=pk)
        s=ASerializer(a,data=request.data,partial=True)
        if s.is_valid():
            s.save()
            return Response({
                "message":"Successfully updated"
            })
        return Response(s.errors)
    else:
        return Response({
            "message":"Method not allowed"
        })
