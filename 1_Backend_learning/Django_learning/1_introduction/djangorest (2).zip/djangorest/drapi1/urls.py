from django.urls import path
from . import views

urlpatterns = [
    path('second_app/',views.a_all),
    path('second_app/<int:pk>',views.a_all),
]
