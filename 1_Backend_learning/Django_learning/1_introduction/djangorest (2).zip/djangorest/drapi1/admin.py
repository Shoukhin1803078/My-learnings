from django.contrib import admin

# Register your models here.
from .models import A
@admin.register(A)
class AAdmin(admin.ModelAdmin):
    list_display = ['id','name','age','email','phone','address','created_at','updated_at']
    # search_fields = ['name']
    # list_filter = ['age']
    # list_per_page = 10
    # ordering = ['-created_at']