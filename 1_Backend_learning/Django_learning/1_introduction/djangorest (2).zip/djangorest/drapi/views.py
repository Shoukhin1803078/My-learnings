from django.shortcuts import render
from .models import Aiquest
from .serializers import AiquestSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.
@api_view(['GET','POST','DELETE'])
def aiquest_create(request, pk=None):
    if request.method=='GET':
        if pk is not None:
            ai=Aiquest.objects.get(pk=pk)
            s=AiquestSerializer(ai)
            return Response(s.data)
        
        ai=Aiquest.objects.all()
        s=AiquestSerializer(ai,many=True)
        return Response(s.data)
    if request.method == 'POST':
        s=AiquestSerializer(data=request.data)
        if s.is_valid():
            s.save()
            return Response({
                "message":"Sucessfully save"
            })
        return Response(s.errors)
    
    if request.method=='DELETE':
        id=pk
        ai=Aiquest.objects.get(pk=pk)
        ai.delete()
        return Response({
            "message":"{pk} id is deleted"
        })