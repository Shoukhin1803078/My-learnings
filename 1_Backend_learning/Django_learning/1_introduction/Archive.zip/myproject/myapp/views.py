from django.shortcuts import render

# Create your views here.
from .models import Post


def post_list(request):
    posts=Post.objects.order_by('-pub_date')
    return render(request,'myapp/post_list.html',{'posts':posts})