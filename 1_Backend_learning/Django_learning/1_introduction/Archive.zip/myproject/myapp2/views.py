

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Book
from .serializers import BookSerializer

@api_view(['GET'])
def get_books(request):
    books = Book.objects.all()
    serializer = BookSerializer(books, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def get_book(request, book_id):
    try:
        book = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return Response({'error': 'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    serializer = BookSerializer(book)
    return Response(serializer.data)

@api_view(['POST'])
def create_book(request):
    serializer = BookSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def update_book(request, book_id):
    try:
        book = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return Response({'error': 'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    serializer = BookSerializer(book, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def delete_book(request, book_id):
    try:
        book = Book.objects.get(id=book_id)
    except Book.DoesNotExist:
        return Response({'error': 'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    book.delete()
    return Response({'message': 'Book deleted successfully'}, status=status.HTTP_204_NO_CONTENT)




















# # from django.shortcuts import render
# # from django.http import JsonResponse
# # from django.http import HttpResponse
# # # Create your views here.
# # def home (request):
# #     return JsonResponse({
# #         'message': 'Hello from myapp2!'
# #     })
# # def about (request):
# #     return HttpResponse('This is the about page of myapp2')
# # def contact (request):
# #     return HttpResponse('This is the contact page of myapp2')

# # def crud_api(request):
# #     if request.method == 'GET':
# #         # Handle GET request
# #         return JsonResponse({'message': 'GET request received'})
# #     elif request.method == 'POST':
# #         # Handle POST request
# #         return JsonResponse({'message': 'POST request received'})
# #     elif request.method == 'PUT':
# #         # Handle PUT request
# #         return JsonResponse({'message': 'PUT request received'})
# #     elif request.method == 'DELETE':
# #         # Handle DELETE request
# #         return JsonResponse({'message': 'DELETE request received'})
# #     else:
# #         return JsonResponse({'error': 'Method not allowed'}, status=405)

# # def crud_api(request, id):
# #     if request.method == 'GET':
# #         # Handle GET request for a specific ID
# #         return JsonResponse({'message': f'GET request received for ID {id}'})
# #     elif request.method == 'POST':
# #         # Handle POST request for a specific ID
# #         return JsonResponse({'message': f'POST request received for ID {id}'})
# #     elif request.method == 'PUT':
# #         # Handle PUT request for a specific ID
# #         return JsonResponse({'message': f'PUT request received for ID {id}'})
# #     elif request.method == 'DELETE':
# #         # Handle DELETE request for a specific ID
# #         return JsonResponse({'message': f'DELETE request received for ID {id}'})
# #     else:
# #         return JsonResponse({'error': 'Method not allowed'}, status=405)