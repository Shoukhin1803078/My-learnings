# myapp/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('books/', views.get_books),
    path('books/create/', views.create_book),
    path('books/<int:book_id>/', views.get_book),
    path('books/<int:book_id>/update/', views.update_book),
    path('books/<int:book_id>/delete/', views.delete_book),
]




# from django.urls import path
# from . import views

# urlpatterns = [
#     path('myapp2/', views.home),
#     path('myapp2/about/', views.about),
#     path('myapp2/contact/', views.contact),
#     path('myapp2/crud_api/', views.crud_api),
#     path('myapp2/crud_api/<int:id>/', views.crud_api),
# ]