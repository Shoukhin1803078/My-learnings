from django.apps import AppConfig


class DrapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drapi'
